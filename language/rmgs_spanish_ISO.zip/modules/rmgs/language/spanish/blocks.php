<?php
/*******************************************************************
* $Id: blocks.php,v 0.1.2 01/03/2006 22:26 BitC3R0 Exp $           *
* ------------------------------------------------------           *
* RMSOFT Gallery System 2.0                                        *
* Sistema Avanzado de Galeras                                     *
* CopyRight  2005 - 2006. Red Mxico Soft                         *
* http://www.redmexico.com.mx                                      *
* http://www.xoops-mexico.net                                      *
*                                                                  *
* This program is free software; you can redistribute it and/or    *
* modify it under the terms of the GNU General Public License as   *
* published by the Free Software Foundation; either version 2 of   *
* the License, or (at your option) any later version.              *
*                                                                  *
* This program is distributed in the hope that it will be useful,  *
* but WITHOUT ANY WARRANTY; without even the implied warranty of   *
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the     *
* GNU General Public License for more details.                     *
*                                                                  *
* You should have received a copy of the GNU General Public        *
* License along with this program; if not, write to the Free       *
* Software Foundation, Inc., 59 Temple Place, Suite 330, Boston,   *
* MA 02111-1307 USA                                                *
*                                                                  *
* ------------------------------------------------------           *
* blocks.php:                                                      *
* Archivo de lenguaje para los bloques                             *
* ------------------------------------------------------           *
* @copyright:  2005 - 2006. BitC3R0.                              *
* @autor: BitC3R0                                                  *
* @paquete: RMSOFT GS v2.0                                         *
* @version: 0.1.2                                                  *
* @modificado: 01/03/2006 10:26:36 p.m.                            *
*******************************************************************/
define('_BK_RMGS_BY','Por:');
define('_BK_RMGS_DATE','Fecha: ');
define('_BK_RMGS_DOWNS','Accesos: ');
define('_BK_RMGS_VOTES','Votos: ');
define('_BK_RMGS_CATEGOS','Categoras:');
define('_BK_RMGS_SELEC','Seleccionar...');
define('_MI_RMGS_BKREC_NUMBER','N�mero de Im�genes:');
define('_MI_RMGS_BKREC_COLS','N�mero de Columnas:');
//Added by Kaotik
define('_MI_RMGS_RANDOMIMGBK','Im�genes al Azar:');
define('_MI_RMGS_BKCOL_NUMBER','N�mero de Columnas:');
?>